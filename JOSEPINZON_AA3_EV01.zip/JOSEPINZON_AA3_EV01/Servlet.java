import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "BuscarEquipoServlet", urlPatterns = {"/buscarEquipo"})
public class BuscarEquipoServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Buscar Equipo</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Buscar Equipo</h1>");
            out.println("<form method='get'>");
            out.println("Nombre del equipo: <input type='text' name='nombre'><br>");
            out.println("Modelo del equipo: <input type='text' name='modelo'><br>");
            out.println("Número de serie: <input type='text' name='serie'><br>");
            out.println("<input type='submit' value='Buscar'>");
            out.println("</form>");
            String nombre = request.getParameter("nombre");
            String modelo = request.getParameter("modelo");
            String serie = request.getParameter("serie");
            if (nombre != null && !nombre.isEmpty() || modelo != null && !modelo.isEmpty() || serie != null && !serie.isEmpty()) {
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:8080/evidencia", "root", "");
                    PreparedStatement ps = con.prepareStatement("SELECT * FROM mantenimiento WHERE Nombre_equipo LIKE ? AND Modelo_equipo LIKE ? AND Numero_serie LIKE ?");
                    ps.setString(1, "%" + nombre + "%");
                    ps.setString(2, "%" + modelo + "%");
                    ps.setString(3, "%" + serie + "%");
                    ResultSet rs = ps.executeQuery();
                    out.println("<table border=1>");
                    out.println("<tr><th>ID</th><th>Nombre</th><th>Modelo</th><th>Número de Serie</th></tr>");
                    while (rs.next()) {
                        out.println("<tr>");
                        out.println("<td>" + rs.getInt("id") + "</td>");
                        out.println("<td>" + rs.getString("Nombre_equipo") + "</td>");
                        out.println("<td>" + rs.getString("Modelo_equipo") + "</td>");
                        out.println("<td>" + rs.getString("Numero_serie") + "</td>");
                        out.println("</tr>");
                    }
                    out.println("</table>");
                    con.close();
                } catch (SQLException e) {
                    out.println("Error al buscar el equipo: " + e.getMessage());
                }
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
