package evidencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Evidencia {
    
    // Datos de conexión a la base de datos
    static final String URL = "jdbc:mysql://localhost:3306/evidencia";
    static final String USUARIO = "root";
    static final String PASSWORD = "";
    
    public static void main(String[] args) {
        
        Connection conexion = null;
        Statement statement = null;
        ResultSet rs = null;
        
        try {
          
            Class.forName("com.mysql.cj.jdbc.Driver");
            
  
            conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
            

            statement = conexion.createStatement();
            
            rs = statement.executeQuery("SELECT * FROM mantenimiento");
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombreEquipo = rs.getString("Nombre_equipo");
                String numeroSerie = rs.getString("Numero_serie");
                
                System.out.println(id + " - " + nombreEquipo + " - " + numeroSerie);
            }
            
            statement.executeUpdate("INSERT INTO mantenimiento (Nombre_equipo, Numero_serie) VALUES ('Autoclave', '489484')");
            
            int filasAfectadas = statement.executeUpdate("UPDATE mantenimiento SET Nombre_equipo = 'Nuevo Equipo' WHERE id = 15");
            
            System.out.println("Filas actualizadas: " + filasAfectadas);
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Evidencia.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (rs != null) rs.close();
                if (statement != null) statement.close();
                if (conexion != null) conexion.close();
            } catch (SQLException ex) {
                Logger.getLogger(Evidencia.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
